Add your own project photo here, e.g. rc-car.jpg. Update the README image path if needed.
